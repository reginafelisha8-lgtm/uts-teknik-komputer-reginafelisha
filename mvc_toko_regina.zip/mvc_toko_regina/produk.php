<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

if (isset($_POST['tambah'])) {
    $nama = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $stmt = mysqli_prepare($conn,
        "INSERT INTO produk (nama_produk, harga, stok) VALUES (?, ?, ?)"
    );
    mysqli_stmt_bind_param($stmt, "sii", $nama, $harga, $stok);
    mysqli_stmt_execute($stmt);

    header("Location: produk.php");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];

    mysqli_query($conn, "DELETE FROM produk WHERE id = $id");

    header("Location: produk.php");
    exit;
}

$data = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kelola Produk</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<h2>Kelola Produk</h2>

<form method="POST">
    <input type="text" name="nama_produk" placeholder="Nama Produk" required>
    <input type="number" name="harga" placeholder="Harga" required>
    <input type="number" name="stok" placeholder="Stok" required>
    <button type="submit" name="tambah">Tambah Produk</button>
</form>

<table>
    <tr>
        <th>ID</th>
        <th>Nama Produk</th>
        <th>Harga</th>
        <th>Stok</th>
        <th>Aksi</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($data)) : ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['nama_produk']) ?></td>
        <td>Rp<?= number_format($row['harga']) ?></td>
        <td><?= $row['stok'] ?></td>
        <td>
            <a href="edit_produk.php?id=<?= $row['id'] ?>">Edit</a> |
            <a href="produk.php?hapus=<?= $row['id'] ?>"
               onclick="return confirm('Yakin ingin menghapus produk?')">Hapus</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<br>
<a href="dashboard.php">Kembali ke Dashboard</a>

</body>
</html>