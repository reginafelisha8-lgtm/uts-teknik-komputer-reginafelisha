<?php
session_start();
include 'koneksi.php';

$pesan = '';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    $data = mysqli_fetch_assoc($query);

    if ($data && password_verify($password, $data['password'])) {
        $_SESSION['admin'] = $data['username'];
        header("Location: dashboard.php");
        exit;
    } else {
        $pesan = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Admin</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="login-container">
    <h2>LOGIN ADMIN</h2>
    <p>Silakan masuk untuk mengelola produk</p>

    <form method="POST">
        <input type="text" name="username"
            placeholder="Username" required>

        <input type="password" name="password"
            placeholder="Password" required>

        <button type="submit" name="login">Login</button>

        <p><?= $pesan ?></p>
    </form>
</div>

<form method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" name="login">Login</button>
    <p><?= $pesan ?></p>
</form>

</body>
</html>