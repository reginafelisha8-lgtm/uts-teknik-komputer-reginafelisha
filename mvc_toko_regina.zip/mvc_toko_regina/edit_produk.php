<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

$id = (int) ($_GET['id'] ?? 0);

$stmt = mysqli_prepare($conn, "SELECT * FROM produk WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$produk = mysqli_fetch_assoc($result);

if (!$produk) {
    die("Produk tidak ditemukan!");
}

if (isset($_POST['update'])) {
    $nama = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $stmt = mysqli_prepare($conn,
        "UPDATE produk SET nama_produk = ?, harga = ?, stok = ? WHERE id = ?"
    );
    mysqli_stmt_bind_param($stmt, "siii", $nama, $harga, $stok, $id);
    mysqli_stmt_execute($stmt);

    header("Location: produk.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Produk</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<h2>Edit Produk</h2>

<form method="POST">
    <input type="text" name="nama_produk"
        value="<?= htmlspecialchars($produk['nama_produk']) ?>" required>

    <input type="number" name="harga"
        value="<?= $produk['harga'] ?>" required>

    <input type="number" name="stok"
        value="<?= $produk['stok'] ?>" required>

    <button type="submit" name="update">Simpan Perubahan</button>
</form>

<a href="produk.php">Kembali</a>

</body>
</html>