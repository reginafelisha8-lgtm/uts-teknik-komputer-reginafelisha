<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

$total_produk = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM produk")
)['total'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<h2>Dashboard Admin</h2>

<h3>Selamat Datang, <?= htmlspecialchars($_SESSION['admin']) ?>!</h3>

<div class="dashboard-card">
    <h3>Total Produk</h3>
    <h1><?= $total_produk ?></h1>
    <a href="produk.php">Kelola Produk</a>
</div>

<br>

<a href="produk.php">Kelola Produk</a> |
<a href="logout.php">Logout</a>

</body>
</html>